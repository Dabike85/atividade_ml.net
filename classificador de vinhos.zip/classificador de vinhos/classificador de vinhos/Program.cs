﻿using System;
using System.Collections.Generic;
using Classificador_de_vinhosML.Model;


namespace classificador_de_vinhos
{
    class Program
    {
        static void Main(string[] args)
        {
            // Add input data
            var input = new List<ModelInput>();
            input.Add(new ModelInput
            {
                fixed_acidity = "7",
                volatile_acidity = "0.27",
                citric_acid = "0.36",
                residual_sugar = "20.7",
                chlorides = "0.045",
            });

            // Load model and predict output of sample data
            ModelOutput result = ConsumeModel.Predict(input);
        }
    }
}
